from django.apps import AppConfig


class TasksAppConfig(AppConfig):
    name = 'tasks_app'
